$(document).ready(function(){
	
	$('#pg').jphotogrid({
		baseCSS: {
			width: '175px',
			height: '117px',
			padding: '0px'
		},
		selectedCSS: {
			top: '50px',
			left: '100px',
			width: '500px',
			height: '360px',
			padding: '10px'
		}
	});
		
});